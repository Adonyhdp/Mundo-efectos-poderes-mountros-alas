import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import {defineConfig} from 'vite';
import {VitePWA} from 'vite-plugin-pwa';
import {flyffTerrainTextures} from './tools/flyff/terrain-textures.mjs';

export default defineConfig(() => {
  return {
    base: './',
    plugins: [
      react(),
      tailwindcss(),
      flyffTerrainTextures(),
      VitePWA({
        base: './',
        registerType: 'autoUpdate',
        includeAssets: ['icon.svg', 'apple-touch-icon.png', 'models/*.glb'],
        manifest: {
          id: './',
          name: 'MU Lorencia Offline & Sync',
          short_name: 'MU Lorencia',
          description:
            'Juego Web3D Babylon.js Offline-First con IndexedDB (Dexie), modelos .glb medievales, 4 mapas MU y un mundo Madrigal de 9.44 km², sincronización con GitHub/Cloud y kit APK auto-actualizable.',
          theme_color: '#0c1018',
          background_color: '#0c1018',
          display: 'standalone',
          orientation: 'landscape',
          start_url: './',
          scope: './',
          icons: [
            {
              src: './pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: './pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: './pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          globPatterns: [
            '**/*.{js,css,html,ico,png,svg,webmanifest}',
            'flyff/**/*.{glb,json,f32,u8,wav}',
            'openmu/**/*.{glb,json,wav,mp3,ogg}',
            'models/**/*.glb',
            'sql-wasm.wasm',
          ],
          globIgnores: ['**/node_modules/**/*', 'assets/aistudio/**'],
          maximumFileSizeToCacheInBytes: 25 * 1024 * 1024,
          cleanupOutdatedCaches: true,
          clientsClaim: true,
          skipWaiting: true,
          navigateFallback: 'index.html',
          runtimeCaching: [
            {
              urlPattern: /\/ota-manifest\.json$/i,
              handler: 'NetworkOnly',
            },
            {
              urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
              handler: 'StaleWhileRevalidate',
              options: {
                cacheName: 'google-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
            {
              urlPattern: /^https:\/\/fonts\.gstatic\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'gstatic-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
          ],
        },
        devOptions: {
          enabled: false,
        },
      }),
      // Copies src/assets into dist/ and stamps buildTimestamp in dist/ota-manifest.json
      {
        name: 'copy-unbundled-src-assets',
        apply: 'build',
        closeBundle(error?: Error): void {
          if (error) {
            return;
          }
          const distDir = path.resolve(import.meta.dirname, 'dist');
          const srcAssets = path.resolve(import.meta.dirname, 'src/assets');
          const distAssets = path.resolve(distDir, 'src/assets');
          if (fs.existsSync(distDir) && fs.existsSync(srcAssets)) {
            fs.cpSync(srcAssets, distAssets, {recursive: true, force: true});
          }
          const manifestPath = path.resolve(distDir, 'ota-manifest.json');
          if (fs.existsSync(manifestPath)) {
            try {
              const parsed = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
              parsed.buildTimestamp = new Date().toISOString();
              fs.writeFileSync(manifestPath, JSON.stringify(parsed, null, 2), 'utf8');
            } catch {
              // ignore
            }
          }
        },
      },
    ],
    build: {
      rolldownOptions: {
        output: {
          manualChunks(id: string) {
            if (id.includes('@babylonjs/loaders')) return 'babylon-loaders';
            if (id.includes('@babylonjs/core')) return 'babylon-core';
            if (id.includes('dexie')) return 'dexie-db';
          },
        },
      },
    },
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
