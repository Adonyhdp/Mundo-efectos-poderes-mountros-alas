# MU Lorencia Offline & Sync — Kit APK Auto-Actualizable

Este paquete contiene el proyecto Android WebView/Capacitor + el Workflow de GitHub Actions para generar un **archivo APK único** que siempre ejecuta la versión web más reciente (y funciona offline gracias al Service Worker + SQLite WASM integrado).

## 1. Cómo evitar el error de GitHub de 320MB y permisos
Cuando subes archivos pesados (>100MB, como carpetas `node_modules/`, `dist/` o `android/build/`), GitHub rechaza el push con errores de permisos o tamaño de archivo.

**Regla de oro:**
1. Nunca subas `node_modules/`, `dist/`, `build/`, ni `.apk` directamente por `git push`. El archivo `.gitignore` ya los excluye.
2. Usa **commits pequeños por paso** (ej: primero `src/`, luego `server.ts`, luego `.github/workflows/build-apk.yml`).
3. En GitHub, si usas HTTPS con Token (PAT), verifica que tu token tenga marcados los permisos: `repo` y `workflow`.
4. Deja que **GitHub Actions** compile el APK en la nube gratis cada vez que hagas `git push`.

## 2. Cómo funciona la auto-actualización dentro del APK
- El APK abre el juego en un **WebView nativo con WebGL2 + IndexedDB + Web Bluetooth + Service Worker** apuntando a: `https://zoeyjf555.github.io`.
- Cada vez que actualizas tu repositorio, el servidor web y el Service Worker actualizan el juego automáticamente dentro del APK sin obligar al usuario a reinstalar el APK cada día.
- Si además cambias permisos nativos de Android, GitHub Actions genera un nuevo `app-debug.apk` en la pestaña **Releases** del repositorio.
