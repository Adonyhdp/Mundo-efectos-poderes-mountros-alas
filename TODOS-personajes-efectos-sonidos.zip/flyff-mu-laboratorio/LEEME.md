<!-- coderabbit-ai-generated:v1 -->

# Laboratorio Flyff × MU — prueba local

Conversión y laboratorio generados por CodeRabbit. No se han cambiado ni publicado archivos del repositorio de tu juego.

## Qué puedes abrir y probar

- Diez personajes: BK (`DK`), Elfa/Elfo (`ELF`), Mago/Maga (`DW`), Dark Lord (`DL`) y Magic Gladiator (`MG`), cada clase en masculino y femenino.
- Son modelos y conjuntos originales de Flyff adaptados a estas cinco etiquetas de MU. No son diez modelos de clases MU encontrados en el recurso original. Se conservan geometría, UV y píxeles de las texturas de los personajes.
- Cada variante tiene un GLB con ropa básica, arma y esqueleto de 30 huesos; otro GLB contiene el cuerpo base. Hay 13 clips nativos por variante: reposo, caminar, correr, cuatro fases de salto, daño, muerte, ataque y tres fases de lanzamiento.
- Diez escenas `.blend` editables con sus imágenes empaquetadas y diez fotografías PNG renderizadas desde los GLB. El cuerpo base se entrega por separado.
- Cinco espacios de equipo: casco, torso/pantalón, guantes, botas y arma. El visor retira la pieza al agotarse su durabilidad y muestra el cuerpo base. Casco y arma generan una pieza rígida que cae. No incluye cortes arbitrarios, ropa desgarrada ni un sistema físico de fragmentación de toda la armadura.
- 28 definiciones de efectos originales, sus capas, curvas, texturas y mallas convertidas, más 32 WAV: pasos, salto, caída, voces, golpes y poderes. Hay **una textura ausente en el origen**, `magician_fire_casting.dds`; queda registrada en su JSON y no se usa en las recetas seleccionadas.
- Las seis habilidades de cada clase usan los datos existentes de tu juego, junto a una selección de efectos y sonidos. Varias habilidades comparten recursos. No se ha convertido todo el catálogo de poderes del cliente Flyff.
- Mundo de **3072 × 3072 metros** (9,437184 km²), dividido en 36 sectores de 512 m. Usa un recorte del terreno y las colocaciones de Madrigal que contiene Flaris. Dos villas con huella de 720 m y el cráter volcánico son añadidos de esta prueba. Se entregan árboles, casas y otros objetos originales, agua simplificada y alturas continuas. No son quince mapas diferentes.

## Descargar y ejecutar

Abre `DESCARGAS.html` para ver los paquetes, sus tamaños y hashes. Descarga los cinco paquetes de personajes, el visor común, todas las partes del mundo y todas las partes de texturas. **Descomprime todos en la misma carpeta**; todos contienen la misma raíz `flyff-mu-laboratorio/`.

Desde esa carpeta raíz ejecuta:

```sh
python3 -m http.server 4175 --bind 127.0.0.1
```

Abre `http://127.0.0.1:4175/`. Abrir el HTML con `file://` no permite cargar los modelos mediante `fetch`. El visor empaquetado no necesita descargar bibliotecas de Internet. El sonido se activa pulsando el botón correspondiente.

- Personajes: elige clase y variante, gira arrastrando, camina, corre o salta; prueba el equipo y el duelo.
- Poderes: pulsa 1–6 o sus botones. El duelo aplica daño, consume maná/energía y desgasta la pieza seleccionada. Es una demostración local; no es lógica de servidor.
- Mundo: consulta el mapa, las fotografías y las coordenadas. “Explorar en 3D” carga el sector seleccionado en Babylon cuando hay WebGL; permite inspección con cámara orbital. No implementa todavía desplazamiento del jugador con colisión en el mundo.
- El Chromium de esta Preview no ofrece WebGL. Por eso el personaje se dibuja mediante un rasterizador CPU de la **malla 3D real**, con piel y animación. Las partículas GPU y la exploración 3D del mundo necesitan un navegador con WebGL. Las fotos del mundo se renderizaron en Blender a partir de los archivos entregados.

## Carpetas y formatos

| Carpeta/archivo | Contenido |
| --- | --- |
| `personajes/<clase>/` | GLB, cuerpo base, BLEND y atributos originales de cada animación |
| `fotos/` | Diez PNG y lámina conjunta |
| `texturas/` | Texturas originales convertidas a PNG sin repintar |
| `efectos/` | JSON de capas y curvas, texturas PNG y mallas GLB |
| `audio/` | WAV originales seleccionados |
| `mundo/tiles/` | 36 terrenos GLB, alturas de 4 m, texturas y superficies |
| `mundo/modelos/` | Modelos GLB de casas, árboles y otros objetos |
| `mundo/colisiones/` | Geometría de colisión nativa convertida a JSON |
| `mundo/mundo.json` | Posiciones, escalas, sectores, ciudades y procedencia |
| `integracion/` | Cargadores y demostración de equipo, sonido, combate y efectos |
| `fuente/` | Conversores reproducibles y guiones de render |
| `pruebas/` | Comprobaciones de archivos y del comportamiento en Babylon |
| `validacion-*.json` | Resultados de las comprobaciones |
| `licencias/` | Licencia del código y avisos originales de los recursos |

Los GLB contienen sus texturas; las copias PNG independientes sirven para editar y para el visor CPU. Las alturas y las posiciones se expresan en metros; los GLB siguen el sistema derecho de glTF y el cargador aplica la conversión de Babylon. El manifiesto del mundo expone X/Y/Z del motor Babylon con Y arriba.

## Compatibilidad con tu juego

Se probó la carga en **Babylon.js 9.37.1**, la versión de tu repositorio `ZoeyJF555/Mu-Offline-Mobile-nuevo-`, revisión `0a87fbfd914ae6dd0874797405fb619ce694d17a`. Los archivos son GLB/PNG/WAV/JSON, formatos que ese motor puede consumir. **Todavía no se han conectado al flujo del juego original**: su motor actual reconstruye un modelo genérico por clase y fija el arma al objeto raíz; hace falta sustituir ese camino por el cargador con esqueleto y añadir la selección de variante.

Con un empaquetador ESM y las dependencias `@babylonjs/core` y `@babylonjs/loaders` fijadas a `9.37.1`:

```js
import { FlyffCharacter, FlyffAudio, readJSON } from './integracion/flyff-assets.js';
const base = new URL('/assets/flyff-mu-laboratorio/', location.origin).href;
const personajes = await readJSON(base, 'personajes.json');
const multimedia = await readJSON(base, 'efectos-audio.json');
const audio = new FlyffAudio(base, multimedia.sounds);
const personaje = await FlyffCharacter.load(scene, base, personajes[0], audio);
// En el bucle del juego, con dt en segundos:
personaje.update(dt, { moving: true, running: false, height: alturaDelSuelo });
// Desde una interacción explícita del jugador:
await audio.unlock();
```

El módulo comparte la piel del cuerpo con el esqueleto animado y sujeta las armas a los puntos nativos de las manos. Las matrices de unión originales contenían ruido numérico del orden de 0,0000002; se normalizó su rotación para producir glTF válido. Las transformaciones locales de las piezas rígidas se hornean en sus vértices y las normales se normalizan.

## Comprobaciones y límites

- Los diez modelos y sus cuerpos cargan con los huesos y clips esperados. Se comprobó movimiento de vértices al atacar, salto con retorno al suelo, cuerpo al retirar equipo, caída del casco y seis habilidades por clase.
- Se cotejaron las posiciones y UV de 70 mallas, 10.536 muestras de rotación y 70 texturas con los archivos nativos. Las imágenes de los personajes conservan los píxeles originales.
- Los 32 WAV se decodificaron con Web Audio en Chromium. Se comprobaron los bordes de los 36 terrenos y las referencias a modelos, efectos y audio.
- El validador independiente de Khronos comprueba todos los GLB. Consulta `validacion-formato.json` para los resultados y los avisos conservados, incluidos los de jerarquías de mallas con piel y triángulos degenerados de origen.
- La reproducción de partículas, cilindros y agua es una adaptación al motor Babylon; **no se ha demostrado equivalencia visual al 100% con el cliente original**. Los objetos animados del entorno se exportan en pose estática.
- Los sectores y modelos compartidos reducen la carga inicial, pero no se ha medido rendimiento en un móvil real. No hay LOD completo ni prueba de memoria de una sesión larga.
- Se entrega la geometría de colisiones; aún no gobierna el movimiento del jugador. Los pueblos no tienen interiores accesibles, NPC, economía ni misiones conectadas. El duelo no es multijugador.

## Procedencia y derechos

Fuente pública: https://github.com/ed3ath/flyff-web-mmo — revisión fijada `7986e75c884174892edc98cc2151df7fcda331fd`.

El código tiene licencia Apache-2.0. Los avisos de `reference/README.md` y `docs/ASSET_SETUP.md` describen los recursos originales de Flyff como propietarios y para referencia. **Que el repositorio sea público no acredita permiso para redistribuir esos recursos ni publicarlos como arte propio.** Esta entrega es un laboratorio local solicitado para evaluar la conversión. Antes de distribuir un juego con ellos necesitas verificar los permisos correspondientes. Se conservan los avisos originales en `licencias/`.

Los conversores verifican cada descarga contra el identificador de blob del árbol Git fijado. `fuente/arbol-origen.json.gz` permite reproducir la selección sin depender de la rama actual. Usa `FLYFF_SOURCE_CACHE` para elegir la caché; de forma predeterminada se reutiliza la de esta tarea o `~/.cache/flyff-mu-laboratorio/source`. Las conversiones requieren Python con NumPy/Pillow; los renders requieren Blender 5.0.1. No contienen credenciales.
